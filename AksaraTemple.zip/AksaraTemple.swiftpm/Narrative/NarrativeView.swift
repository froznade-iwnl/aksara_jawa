//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 22/2/25.
//

import SwiftUI

struct NarrativeView: View {
    
    @EnvironmentObject var storyManager: NarrativeManager
    
    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea(.all)
            
           
            ForEach(storyManager.story.indices.reversed(), id:\.self) { index in
                Narrative(story: storyManager.story[index])
                    .opacity(storyManager.story[index].showStory ? 1:0)
            }
            .padding()
            
            VStack {

                    Button {
                        withAnimation(.smooth) {
                            storyManager.finished.toggle()
                        }
                    } label: {
                        Image(systemName: "chevron.right.to.line")
                            .foregroundStyle(.black)
                            .font(.largeTitle)
                            .padding()
                            .background(
                                Image("button")
                                    .resizable()
                            )
                    }
                
                Spacer()

            }
            .padding()
        }
        .onTapGesture {
            withAnimation(.smooth) {
                storyManager.nextStory()
            }
        }
    }
}

struct Narrative: View {
    var story: Story
    
    var body: some View {
        ZStack {
            
            Color.black
                .ignoresSafeArea(.all)
            
            VStack {
                Spacer()
                
                HStack {
                    Spacer()
                    
                    if story.image != "" {
                        Image(story.image)
                            .resizable()
                            .frame(maxWidth: 500, maxHeight: 500)
                    }
                    
                    Text(story.story)
                        .font(.largeTitle)
                        .foregroundStyle(.white)
                        .frame(maxWidth: 500)
                        .padding(.leading, 20)
                        .italic(story.image == "")
                    
                    Spacer()
                }
                
                Text("Tap anywhere to continue")
                    .font(.caption).italic()
                    .foregroundStyle(.white).opacity(0.5)
                    .padding(.top, 50)
                
                Spacer()
                
            }
        }
    }
}

