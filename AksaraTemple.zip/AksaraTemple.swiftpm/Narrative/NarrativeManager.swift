//
//  File.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 21/2/25.
//

import Foundation
import SwiftUI

struct Story: Hashable, Identifiable {
    let id = UUID()
    var story: String
    var image: String
    var showStory: Bool = false
}

enum AppState {
    case splash
    case option
    case storyMode
    case game
}

class NarrativeManager: ObservableObject {
    static let shared = NarrativeManager()
    @Published var story: [Story] = []
    @Published var currentIndex = 0
    @Published var finished = false
    
    init() {}
    
    func nextStory(){
        story[currentIndex].showStory = false
        
        if currentIndex+1 >= story.count {
                finished = true
        }else{
            currentIndex += 1
            story[currentIndex].showStory = true
        }
    }
    
    func getViewStory(status: AppState, extra: Bool = false) {
        finished = false
        currentIndex = 0
        switch status {
        case .splash:
            print("Hello")
        case .option:
            story = intro
            if extra {
                story = outro
            }
            story[0].showStory = true
        case .storyMode:
            print("Hello")
        case .game:
            print("Hello")
        }
    }
    
    func getGameStory(status: Levels, intro: Bool) {
        finished = false
        currentIndex = 0
        
        switch status {
        case .level1:
            if intro {
                story = level1_intro
            }else{
                story = level1_outro
            }
            story[0].showStory = true
        case .level2:
            if intro {
                story = level2_intro
            }else{
                story = level2_outro
            }
            story[0].showStory = true
        case .level3:
            if intro {
                story = level3_intro
            }else{
                story = level3_outro
            }
            story[0].showStory = true
        case .level4:
            if intro {
                story = level4_intro
            }else{
                story = level4_outro
            }
            story[0].showStory = true
        }
        }
}

let intro: [Story] = [Story(story: "\"Class, we’re going to learn Aksara Jawa (Javanese Script) today,\"\n\nsaid your teacher.", image: ""), Story(story: "You thought to yourself, \"What's the point in learning all of this when we already have alphabets?\"", image: "char-ask"), Story(story: "Booring~ Let's just sleep instead", image: "char-sleep"), Story(story: "Suddenly, it felt like your mind is spinning~!", image: "isekai"), Story(story: "You looked around, everything feels unfamiliar.\n\nA sign on the wall piqued your curiosity.", image: ""), Story(story: "You lazy girl!\n\nUnless you can solve all the puzzles, you will be trapped here forever. HAHAHAHA!", image: "sign"), Story(story: "Oh, no! I need to get out of here or I won't be able to drink hot chocolate again!", image: "")]

let level1_intro: [Story] = [Story(story: "You see syllables on the wall and stone boxes on the floor.", image: "intro_room"), Story(story: "\"I think I need to put the correct Aksara (scripture) in the wall to solve the puzzle.\"", image: "intro_room")]

let level1_outro: [Story] = [Story(story: "The door opens after you put all the pieces to its place. You saw some sculpture on the wall.", image: "door"), Story(story: "You read the sign nearby.", image: ""), Story(story: "Ha Na Ca Ra Ka – There were two loyal servants, entrusted with a sacred duty.", image: "sculpture-1"), Story(story: "I wonder what this story is trying to tell me...", image: "char-ask")]

let level2_intro: [Story] = [Story(story: "Another puzzle is waiting for you", image: "intro_room")]

let level2_outro: [Story] = [Story(story: "Again, the door opens upon solving it", image: "door"), Story(story: "More sculpture?", image: ""), Story(story: "Da Ta Sa Wa La – A misunderstanding happened, neither willing to yield.", image: "sculpture-2"), Story(story: "Hmmm, are they going to fight?", image: "char-ask")]

let level3_intro: [Story] = [Story(story: "Uhm, more puzzle is waiting...", image: "intro_room")]

let level3_outro: [Story] = [Story(story: "Unsurprisingly, the door opens.", image: "door"), Story(story: "More sculpture? Can't I get a glass of hot chocolate instead???", image: "sculpture-3"), Story(story: "You still read the sign nonetheless.", image: ""), Story(story: "Pa Dha Ja Ya Nya – Both warriors fought in a fatal duel, proving their unwavering loyalty.", image: "sculpture-3"), Story(story: "Ooh, fights! I wonder who won that fight...", image: "char-ask")]

let level4_intro: [Story] = [Story(story: "More puzzles?! Don't tell me that I'm trapped here for eternity?!!", image: "intro_room")]

let level4_outro: [Story] = [Story(story: "Of course, the door opens. What else?", image: "door"), Story(story: "Oh, that's...", image: ""), Story(story: "Ma Ga Ba Tha Nga – Their sacrifice left only their lifeless bodies behind.", image: "sculpture-4"), Story(story: "Oh... Uhm, well now I feel bad about them...", image: "char-ask")]

let outro: [Story] = [
  Story(story: "You step through the final door, a sense of relief washing over you.", image: "door"),
  Story(story: "In front of you stands all the sculptures you’ve seen so far.", image: ""),
  Story(story: "Ha Na Ca Ra Ka – Two loyal servants, entrusted with a sacred duty.", image: "sculpture-1"),
  Story(story: "Da Ta Sa Wa La – A misunderstanding arose, leading to conflict.", image: "sculpture-2"),
  Story(story: "Pa Dha Ja Ya Nya – A fierce battle ensued, proving their unwavering loyalty.", image: "sculpture-3"),
  Story(story: "Ma Ga Ba Tha Nga – In the end, their sacrifice left only their lifeless bodies behind.", image: "sculpture-4"),
  Story(story: "You take a deep breath.\n\n \"This... is the legendary tale behind the Javanese script.\"", image: ""),
  Story(story: "Each set of syllables represents a part of the story. A story of duty, conflict, and sacrifice.", image: "splash"),
  Story(story: "The legend says this is the tale of Aji Saka, the wise king, and his two loyal servants.", image: "sculpture-1"),
  Story(story: "Through their tragedy, the sacred script of Aksara Jawa was born, preserving their story for eternity.", image: "sculpture-4"),
  Story(story: "Maybe... learning Aksara Jawa isn’t so pointless after all.", image: ""),
  Story(story: "The final path opens before you. It’s time to go home.", image: "door"),
]
