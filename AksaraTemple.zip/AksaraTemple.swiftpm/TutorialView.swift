//
//  TutorialView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 24/2/25.
//

import SwiftUI

struct TutorialView: View {
    var body: some View {
        Image("tutorial")
            .resizable()
            .scaledToFill()
    }
}

#Preview {
    TutorialView()
}
