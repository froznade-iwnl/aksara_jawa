//
//  LevelsView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 23/2/25.
//

import SwiftUI

struct LevelsView: View {
    
    @Binding var appState: AppState
    
    @EnvironmentObject var gameManager: GameModel
    
    let levelRow = [GridItem(.fixed(2))]
    
    var body: some View {
        VStack {
            Text("Choose a room to go".capitalized)
                .font(.largeTitle)
                .bold()
                .foregroundStyle(.white)
            
            HStack {
                ForEach(gameManager.levelNames, id:\.id) { level in
                    Button {
                        if !level.locked{
                            gameManager.set_level(level: level.levelSwitch)
                            print(gameManager.wordTested)
                            appState = .game
                        }
                    } label: {
                        LevelBox(level: level)
                            .padding()
                    }
                }
            }
            
            if gameManager.completed {
                Button {
                    appState = .option
                } label: {
                    Image(systemName: "chevron.left")
                        .foregroundStyle(.black)
                        .font(.largeTitle)
                        .padding()
                        .background(
                            Image("button")
                                .resizable()
                        )
                }
            }
            
        }
        .onAppear {
            if gameManager.currentLevelIndex >= 4 {
                gameManager.completed = true
            }
        }
    }
}

struct LevelBox: View {
    var level: LevelID
    var body: some View {
        ZStack {
            Image("button")
                .resizable()
                .frame(width: 200, height: 200)
            
            if level.locked {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.black)
                    .font(.largeTitle)
            } else {
                Text(level.levelName)
                    .font(.largeTitle)
                    .foregroundStyle(.black)
            }
        }
    }
}

#Preview {
    LevelsView(appState: .constant(.storyMode))
}
