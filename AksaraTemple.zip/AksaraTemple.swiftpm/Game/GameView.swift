//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 20/2/25.
//

import SwiftUI

struct GameView: View {
    
    @EnvironmentObject var gameModel: GameModel
    @Binding var appState: AppState
    
    var body: some View {
        ZStack {
            VStack {
                
                WordView(gameModel: gameModel)
                
                
                HStack {
                    
                    VStack{
                        
                        Button {
                            withAnimation(.smooth) {
                                gameModel.showTutorial.toggle()
                            }
                        } label: {
                            Image(systemName: "questionmark")
                                .foregroundStyle(.black)
                                .font(.largeTitle)
                                .padding()
                                .background(
                                    Image("button")
                                        .resizable()
                                        .frame(width: 100, height: 100)
                                )
                                .frame(width: 100, height: 100)
                        }
                        
                        Button {
                            gameModel.showControllerGuide.toggle()
                        } label: {
                            Image(systemName: "character.textbox")
                                .foregroundStyle(!gameModel.showControllerGuide ? .black : .white)
                                .font(.largeTitle)
                                .padding()
                                .background(
                                    Image(gameModel.showControllerGuide ? "hole":"button")
                                        .resizable()
                                        .frame(width: 100, height: 100)
                                    )
                                .frame(width: 100, height: 100)
                        }
                        
                        
                    }
                    .padding()
                    
                    ControllerView(gameModel: gameModel)
                        .padding()
                    
                    
                }
                
            }
            
        }
        .alert("Completed!", isPresented: $gameModel.solved) {
            Button("Yay!", role: .cancel) {
                gameModel.showOutro = true
                gameModel.levelNames[(gameModel.currentLevelIndex+1)%4].locked = false
                gameModel.currentLevelIndex += 1
            }
        }
        .sheet(isPresented: $gameModel.showTutorial) {
            TutorialView()
        }
        .onAppear {
            if gameModel.firstRun {
                gameModel.showTutorial.toggle()
                gameModel.firstRun = false
            }
        }
    }
}

#Preview {
    GameView(appState: .constant(.game))
}
