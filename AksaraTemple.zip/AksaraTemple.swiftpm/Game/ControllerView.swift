//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 20/2/25.
//

import SwiftUI

struct ControllerView: View {
    
    let aksaraRowItem = [GridItem(.fixed(5))]
    @ObservedObject var gameModel: GameModel
    
    var body: some View {
        VStack {
            ForEach(Hanacaraka, id: \.self) { group in
                
                    HStack(spacing: 10) {
                        ForEach(group, id: \.self) {  aksara in
                            AksaraButton(aksara: aksara, currentAnswer: $gameModel.currentAnswer, showGuide: $gameModel.showControllerGuide)
                    }
                }
            }
        }
    }
}

struct AksaraButton: View {
    
    var aksara: Aksara
    @Binding var currentAnswer: String
    @Binding var showGuide: Bool
    
    var body: some View {
        Button {
            currentAnswer = aksara.alpha
        } label: {
            ZStack {
                Image("button")
                    .resizable()
                    .frame(width: 100, height: 100)
                
                VStack {
                    Text(aksara.aksara)
                        .font(.largeTitle)
                    
                    if showGuide {
                        Text(aksara.alpha)
                            .italic()
                    }
                    
                }
                .foregroundColor(.black)
                .frame(minWidth: 100, minHeight: 100)
            }
            .padding()
            .shadow(radius: 5)
        }
    }
}

//#Preview {
//    GameView()
//}
