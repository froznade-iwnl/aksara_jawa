//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 20/2/25.
//

import SwiftUI

struct WordView: View {
    
    @ObservedObject var gameModel: GameModel
    @State var correctAnswer: Bool = true
    
    var body: some View {
        VStack {
            ZStack {
                ForEach(gameModel.wordTested.indices.reversed(), id: \.self) { index in
                  
                    WordBox(word: $gameModel.wordTested[index].word, status: $gameModel.wordTested[index].wordStatus)
                        
                }
            }
            .frame(height: 200)
        }
        .onChange(of: gameModel.currentAnswer) { _ in
            if gameModel.checkAns() {
                gameModel.updateWord()
            } else {
                correctAnswer.toggle()
            }
        }
    }
}


struct WordBox: View {
    @Binding var word: String
    @Binding var status: wordStatus
    @State private var opac: CGFloat = 1
    @State private var shiftY: CGFloat = 0
    
    var body: some View {
        ZStack {
            Image("hole")
                .resizable()
                .frame(width: 100, height:100)
            
            VStack {
                Text(status == .current ? word : status == .answered ? " " : "?")
                    .font(.title)
                    .frame(width: 100, height: 100)
                    .foregroundColor(getTextColor(stat: status))
            }
        }
        .padding()
        .offset(x: 0, y: shiftY)
        .opacity(opac)
        .onChange(of: status) { _ in
            if status == .answered {
                withAnimation(.easeInOut) {
                    shiftY = -100
                    opac = 0
                }
            }
        }
    }
}

func getBoxColor(stat: wordStatus) -> Color {
    if stat == .current {
        return Color.black
    } else if stat == .answered {
        return Color.green
    } else {
        return Color.gray
    }
}

func getTextColor(stat: wordStatus) -> Color {
    if stat == .current {
        return Color.white
    } else if stat == .answered {
        return Color.clear
    } else {
        return Color.white.opacity(0.2)
    }
}

#Preview {
    GameView(appState: .constant(.game))
}
