//
//  File.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 20/2/25.
//

import Foundation

struct Aksara: Hashable {
    let ID = UUID()
    var aksara: String
    var alpha: String
}


let Hanacaraka: [[Aksara]] = [
    [Aksara(aksara: "ꦲ", alpha: "ha"), Aksara(aksara: "ꦤ", alpha: "na"), Aksara(aksara: "ꦕ", alpha: "ca"), Aksara(aksara: "ꦫ", alpha: "ra"), Aksara(aksara: "ꦏ", alpha: "ka")],
    [Aksara(aksara: "ꦢ", alpha: "da"), Aksara(aksara: "ꦠ", alpha: "ta"), Aksara(aksara: "ꦱ", alpha: "sa"), Aksara(aksara: "ꦮ", alpha: "wa"), Aksara(aksara: "ꦭ", alpha: "la")],
    [Aksara(aksara: "ꦥ", alpha: "pa"), Aksara(aksara: "ꦝ", alpha: "dha"), Aksara(aksara: "ꦗ", alpha: "ja"), Aksara(aksara: "ꦪ", alpha: "ya"), Aksara(aksara: "ꦚ", alpha: "nya")],
    [Aksara(aksara: "ꦩ", alpha: "ma"), Aksara(aksara: "ꦒ", alpha: "ga"), Aksara(aksara: "ꦧ", alpha: "ba"), Aksara(aksara: "ꦛ", alpha: "tha"), Aksara(aksara: "ꦔ", alpha: "nga")]
]


struct Word: Hashable {
    let id = UUID()
    var word: String
    var wordStatus: wordStatus = .toAnswer
}

enum wordStatus {
    case current
    case answered
    case toAnswer
}

struct LevelID: Hashable {
    let id = UUID()
    var levelName: String
    var levelSwitch: Levels
    var locked: Bool = true
}

@MainActor
class GameModel: ObservableObject {
    
    @Published var wordTested: [Word]
    @Published var level: Levels = .level4
    @Published var currentIndex: Int = 0
    @Published var currentAnswer: String = ""
    @Published var solved: Bool = false
    @Published var showControllerGuide: Bool = false
    @Published var firstRun = true
    
    @Published var showIntro = true
    @Published var showOutro = false
    @Published var showTutorial = false
    @Published var completed = false
    @Published var levelNames: [LevelID] = [LevelID(levelName: "Room 1", levelSwitch: .level1, locked: false), LevelID(levelName: "Room 2", levelSwitch: .level2), LevelID(levelName: "Room 3", levelSwitch: .level3), LevelID(levelName: "Room 4", levelSwitch: .level4)]
    @Published var currentLevelIndex = 0
    
    init(words: [Word], showGuide: Bool = false) {
        self.wordTested = words
        self.showControllerGuide = showGuide
        currentLevelIndex = 0
        completed = false
    }
    
    func checkAns() -> Bool {
        if  wordTested[currentIndex].word == currentAnswer {
            return true
        }
        return false
    }
    
    func updateWord() {
        wordTested[currentIndex].wordStatus = .answered
        
        if currentIndex >= wordTested.count-1 {
            solved.toggle()
        } else {
            currentIndex += 1
            wordTested[currentIndex].wordStatus = .current
            currentAnswer = ""
        }
    }
    
//    func reset() {
//        var temp: [Word] = []
//        for index in 0..<wordTested.count {
//            temp.append(Word(word: wordTested[index].word))
//        }
//        temp[0].wordStatus = .current
//        wordTested = temp
//        currentIndex = 0
//        currentAnswer = ""
//    }
    
    func set_level(level: Levels){
        currentIndex = 0
        currentAnswer = ""
        showControllerGuide = false
        showIntro = true
        showOutro = false
        
        self.level = level
        
        switch level {
        case .level1:
            wordTested = level1
        case .level2:
            wordTested = level2
        case .level3:
            wordTested = level3
        case .level4:
            wordTested = level4
        }
    }
    
}

enum Levels {
    case level1
    case level2
    case level3
    case level4
}

var level1: [Word] = [
    Word(word: "ha", wordStatus: .current),
    Word(word: "na"),
    Word(word: "ca"),
    Word(word: "ra"),
    Word(word: "ra"),
    Word(word: "ka"),
    Word(word: "ka"),
    Word(word: "ca"),
    Word(word: "na"),
    Word(word: "ca")
]

var level2: [Word] = [
    Word(word: "da", wordStatus: .current),
    Word(word: "ta"),
    Word(word: "sa"),
    Word(word: "wa"),
    Word(word: "la"),
    Word(word: "da"),
    Word(word: "ta"),
    Word(word: "la"),
    Word(word: "wa"),
    Word(word: "sa")
]

var level3: [Word] = [
    Word(word: "pa", wordStatus: .current),
    Word(word: "ja"),
    Word(word: "dha"),
    Word(word: "nya"),
    Word(word: "ja"),
    Word(word: "ya"),
    Word(word: "nya"),
    Word(word: "pa"),
    Word(word: "pa"),
    Word(word: "dha")
]

var level4: [Word] = [
    Word(word: "ma", wordStatus: .current),
    Word(word: "ga"),
    Word(word: "ba"),
    Word(word: "tha"),
    Word(word: "ga"),
    Word(word: "ma"),
    Word(word: "ba"),
    Word(word: "nga"),
    Word(word: "tha"),
    Word(word: "ma"),
    Word(word: "nga")
]


let syllables = ["ha", "na", "ca", "ra", "ka", "da", "ta", "sa", "wa", "la", "pa", "dha", "ja", "ya", "nya", "ma", "ga", "ba", "tha", "nga"]

func splitIntoSyllables(word: String) -> [String] {
    var result: [String] = []
    var remainingWord = word.lowercased()
    
    while !remainingWord.isEmpty {
        var foundSyllable = false
        
        // Check for the longest possible syllable match
        for syllable in syllables.sorted(by: { $0.count > $1.count }) {
            if remainingWord.hasPrefix(syllable) {
                result.append(syllable)
                remainingWord.removeFirst(syllable.count)
                foundSyllable = true
                break
            }
        }
        
        // If no syllable is found, treat the next character as a standalone syllable
        if !foundSyllable {
            let firstCharacter = String(remainingWord.first!)
            result.append(firstCharacter)
            remainingWord.removeFirst()
        }
    }
    
    return result
}

//var level1: [[Word]] = [
//    [Word(word: "ha", wordStatus: .current), Word(word: "na")],
//    [Word(word: "ca"), Word(word: "ra")],
//    [Word(word: "ra"), Word(word: "ka")],
//    [Word(word: "ka"), Word(word: "ca")],
//    [Word(word: "na"), Word(word: "ca")]
//]
//
//var level2: [[Word]] = [
//    [Word(word: "da", wordStatus: .current), Word(word: "ta")],
//    [Word(word: "sa"), Word(word: "wa")],
//    [Word(word: "la"), Word(word: "da")],
//    [Word(word: "ta"), Word(word: "la")],
//    [Word(word: "wa"), Word(word: "sa")]
//]
//
//var level3: [[Word]] = [
//    [Word(word: "pa", wordStatus: .current), Word(word: "ja")],
//    [Word(word: "dha"), Word(word: "nya")],
//    [Word(word: "ja"), Word(word: "ya")],
//    [Word(word: "nya"), Word(word: "pa")],
//    [Word(word: "pa"), Word(word: "dha")]
//]
//
//var level4: [[Word]] = [
//    [Word(word: "ma", wordStatus: .current), Word(word: "ga")],
//    [Word(word: "ba"), Word(word: "tha")],
//    [Word(word: "ga"), Word(word: "ma"), Word(word: "ba")],
//    [Word(word: "nga"), Word(word: "tha")],
//    [Word(word: "ma"), Word(word: "nga")]
//]
