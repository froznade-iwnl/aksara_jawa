//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 23/2/25.
//

import SwiftUI

struct HomeView: View {
    @Binding var appState: AppState
    
    var body: some View {
        ZStack {
            VStack {
                
                    
                Image("splash")
                    .resizable()
                    .frame(width: 500, height: 500)
                
                Text("Aksara Temple")
                    .multilineTextAlignment(.leading)
                    .font(.largeTitle)
                    .foregroundStyle(.white)
                    
                
                .padding(.vertical, 50)
                
                Text("Tap anywhere to start")
                    .font(.caption)
                    .italic()
                    .foregroundStyle(.white).opacity(0.5)
                
            }
        }
        .onTapGesture {
            withAnimation(.easeInOut(duration: 1)) {
                appState = .option
            }
        }
    }
}

#Preview {
    HomeView(appState: .constant(.option))
}
