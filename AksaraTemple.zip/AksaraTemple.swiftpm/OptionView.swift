//
//  SwiftUIView.swift
//  AksaraJawa2
//
//  Created by Raditya Aryo Wahyudi on 23/2/25.
//

import SwiftUI

struct OptionView: View {
    @Binding var appState: AppState
    
    var body: some View {
        HStack {
            
            Spacer()
            
            // Story mode
            Button {
                withAnimation(.smooth) {
                    appState = .storyMode
                }
            } label: {
                ZStack {
                    Image("button")
                        .resizable()
                        .frame(width: 300, height: 300)
                        
                    
                    Text("Story Mode")
                        .font(.largeTitle)
                        .foregroundStyle(.black)
                }
                
            }

            
//            // Endless mode
//            Button {
//                print("Challenge Mode")
//            } label: {
//                ZStack {
//                    Image("button")
//                        .resizable()
//                        .frame(width: 300, height: 300)
//                    
//                    Text("Endless Mode")
//                        .font(.largeTitle)
//                        .foregroundStyle(.black)
//                }
//            }
//            .padding(.leading, 100)

            
            Spacer()
        }
        
    }
}

#Preview {
    OptionView(appState: .constant(.option))
}
