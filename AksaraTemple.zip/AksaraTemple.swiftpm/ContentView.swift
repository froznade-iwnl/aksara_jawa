import SwiftUI

struct ContentView: View {
    @State private var appState: AppState = .splash
    @ObservedObject var gameManager: GameModel = GameModel(words: [])
    @ObservedObject var storyManager: NarrativeManager = NarrativeManager()
    @State private var firstLaunch: Bool = true
    
    
    var body: some View {
        ZStack {
            Image("wall")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all)
            
            Rectangle()
                .foregroundStyle(LinearGradient(gradient: Gradient(colors: [.black, .black.opacity(0.5), .black]), startPoint: .bottom, endPoint: .top))
                .ignoresSafeArea(.all)
                .opacity(0.7)
            
            switch appState {
            case .splash:
                HomeView(appState: $appState)
                
            case .option:
                
                if gameManager.completed {
                    NarrativeView()
                        .environmentObject(storyManager)
                        .onChange(of: storyManager.finished) { _ in
                            if storyManager.finished {
                                appState = .splash
                                gameManager.completed = false
                            }
                        }
                } else {
                    OptionView(appState: $appState)
                }
                
            case .storyMode:
                if firstLaunch {
                    NarrativeView()
                        .environmentObject(storyManager)
                        .onChange(of: storyManager.finished) { _ in
                            if storyManager.finished {
                                firstLaunch = false
                            }
                        }
                } else {
                    LevelsView(appState: $appState)
                        .environmentObject(gameManager)
                }
                
            case .game:
                if gameManager.showIntro {
                    NarrativeView()
                        .environmentObject(storyManager)
                        .onChange(of: storyManager.finished) { _ in
                            if storyManager.finished {
                                gameManager.showIntro = false
                            }
                        }
                } else if gameManager.showOutro {
                    NarrativeView()
                        .environmentObject(storyManager)
                        .onChange(of: storyManager.finished) { _ in
                            if storyManager.finished {
                                appState = .storyMode
                            }
                        }
                } else {
                    GameView(appState: $appState)
                        .environmentObject(gameManager)
                }
            }
            
            VStack {
                
            }.padding()
            
        }
        .onChange(of: appState) { _ in
            withAnimation(.smooth){
                if appState == .option {
                    storyManager.getViewStory(status: .option)
                    if gameManager.completed {
                        storyManager.getViewStory(status: .option, extra: gameManager.completed)
                    }
                }
            }
        }
        .onChange(of: gameManager.level) { _ in
            withAnimation(.smooth){
                storyManager.getGameStory(status: gameManager.level, intro: gameManager.showIntro)
            }
        }
        .onChange(of: gameManager.showOutro) { _ in
            withAnimation(.smooth){
                storyManager.getGameStory(status: gameManager.level, intro: gameManager.showIntro)
            }
        }
    }
}

